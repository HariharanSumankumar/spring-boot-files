package com.cts.employee.model;

import java.util.Date;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;

public class Emp {
	
	@NotNull(message = "Name cannot be NULL")
	private String empName;
	 @NotNull(message ="DOJ date is Not Valid")
	 @DateTimeFormat(pattern = "dd/mm/yyyy")
	private Date doj;
	@Min(value=10, message = "Phone Number should be of 10 digits")
	private Long phoneno;
	 @Email(message = "Email-Id should be a Valid one")
	private String Email;
	 
	 
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public Long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(Long phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	

}
