package com.cognizant.forms.enrollment.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cognizant.forms.enrollment.model.Student;


@Controller
public class EnrollmentController {
	@RequestMapping(value="/Spring4MVCformValidatorExample", method=RequestMethod.GET)
	public String showLoginpage(@ModelAttribute("stud") Student stud) {    //model attribute binds the form to emp 
	  
	return "enroll";     // directs to login.jsp page   at first i direct to the login.jsp page

	}


	@RequestMapping(value="/Spring4MVCformValidatorExamplesuccess", method=RequestMethod.POST)
	public String checkLoginDetails(@Valid@ModelAttribute("stud") Student emp,BindingResult result) {    //model attribute binds the form to emp    //result of validation is at result and that result is used to check for errors here down below

	  
		if(result.hasErrors()) {
			//System.err.println(result.getErrorCount());
			return "enroll";    /// if there is any error ,it will direct to the login page again
		}
		  return "success";     ///if there isn't ,then it goes to success page
		 	 

	}
}
