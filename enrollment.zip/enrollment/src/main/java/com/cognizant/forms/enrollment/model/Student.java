package com.cognizant.forms.enrollment.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.*;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class Student {

	public Student() {}
	@Size(min=3, max=30,message="First Name must be between 3 and 30 characters long")
	private String firstName;
	@Size(min=3, max=30,message="Last Name must be between 3 and 30 characters long")
	private String LastName;
	@SuppressWarnings("deprecation")
	@NotEmpty(message="Please specify your gender")
	private String gender;
	@DateTimeFormat(iso=ISO.DATE)
	private Date dob;
	@NotBlank(message = "Email cannot be blank")	
	private String email;
	@SuppressWarnings("deprecation")
	@NotEmpty(message="Please specify your section")
	private String section;
	@NotBlank(message="Please select your Country")
	private String country;
	
	private boolean firstattempt;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public boolean isFirstattempt() {
		return firstattempt;
	}
	public void setFirstattempt(boolean firstattempt) {
		this.firstattempt = firstattempt;
	}
	public List<String> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}
	@NotEmpty(message = "Please select atleast one subject")
	private List<String> subjects = new ArrayList<String>();
}
