package com.cognizant.forms.enrollment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
