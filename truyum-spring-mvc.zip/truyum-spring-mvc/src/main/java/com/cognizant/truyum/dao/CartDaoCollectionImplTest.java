package com.cognizant.truyum.dao;

import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImplTest {
	public static void main(String[] args) throws CartEmptyException {
		testAddCartItem();
		testGetAllCartItems();
		testRemoveCartItem();
	}
	@SuppressWarnings("static-access")
	static void testRemoveCartItem() {

		CartDaoCollectionImpl cartDaoCollectionImpl = new CartDaoCollectionImpl();
		CartDao cartDao = cartDaoCollectionImpl;
		cartDao.removeCartItem(1, 000004);
		
		//System.out.println("MenuItem list :" + menuItemList);
		System.out.println("HashMap :" + cartDaoCollectionImpl.getUserCarts());

	}
	@SuppressWarnings("static-access")
	static void testGetAllCartItems() throws CartEmptyException {

		CartDaoCollectionImpl cartDaoCollectionImpl = new CartDaoCollectionImpl();
		CartDao cartDao = cartDaoCollectionImpl;

		List<MenuItem> menuItemList = cartDao.getAllCartItems(1);
		System.out.println("MenuItem list :" + menuItemList);
		System.out.println("HashMap :" + cartDaoCollectionImpl.getUserCarts());
		
		

	}
	@SuppressWarnings("static-access")
	static void testAddCartItem() throws CartEmptyException {

		CartDaoCollectionImpl cartDaoCollectionImpl = new CartDaoCollectionImpl();
		CartDao cartDao = cartDaoCollectionImpl;
		cartDao.addCartItem(1, 000004);
		cartDao.addCartItem(1, 000003);
		cartDao.addCartItem(2, 000003);
		System.out.println("HashMap Inside add cart Item:" + cartDaoCollectionImpl.getUserCarts());

	}

}
