package com.cognizant.truyum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.dao.CartDao;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

@Service
public class CartService {

	@Autowired
	private CartDao cartDao;

	public CartDao getCartDao() {
		return cartDao;
	}

	public void setCartDao(CartDao cartDao) {
		this.cartDao = cartDao;
	}

	public List<MenuItem> getAllCartItems(long userid) throws CartEmptyException {
		return cartDao.getAllCartItems(userid);
	}

	public void removeCartItem(long userId, long menuitemid) {
		cartDao.removeCartItem(userId, menuitemid);
	}
	
	public void addToCart(long userId,long menuItemId) {
		cartDao.addCartItem(userId, menuItemId);
	}

}
