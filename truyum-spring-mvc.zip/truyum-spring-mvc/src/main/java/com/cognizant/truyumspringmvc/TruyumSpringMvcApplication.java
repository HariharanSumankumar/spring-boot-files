package com.cognizant.truyumspringmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.cognizant.truyum.controller",
	"com.cognizant.truyum.dao",
	"com.cognizant.truyum.model",
	"com.cognizant.truyum.service",
	"com.cognizant.truyum.util",
	"com.cognizant.truyumspringmvc"})
public class TruyumSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruyumSpringMvcApplication.class, args);
	}

}
